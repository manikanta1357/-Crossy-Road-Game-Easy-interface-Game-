# Crossy_Road-Game
A simple Crossy Road-style arcade game made with HTML, CSS, and JavaScript.
